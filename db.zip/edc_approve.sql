# ************************************************************
# Sequel Pro SQL dump
# Version (null)
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 192.168.0.218 (MySQL 5.6.17-ndb-7.3.5-cluster-gpl-log)
# Database: hospdata
# Generation Time: 2019-10-03 04:51:53 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table edc_approve
# ------------------------------------------------------------

DROP TABLE IF EXISTS `edc_approve`;

CREATE TABLE `edc_approve` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('PAYMENT','CANCEL','TXNCANCEL','REPRINT') DEFAULT 'PAYMENT' COMMENT 'ประเภท',
  `action` varchar(60) DEFAULT NULL COMMENT 'ประเภทที่ออกจากเครื่อง edc',
  `approve_code` varchar(50) DEFAULT '',
  `trace` varchar(50) DEFAULT NULL,
  `amount` double(12,2) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL,
  `pid` varchar(32) DEFAULT NULL,
  `hn` varchar(20) DEFAULT NULL,
  `vn` varchar(20) DEFAULT NULL,
  `edc_id` int(11) DEFAULT NULL,
  `response_data` text COMMENT 'raw data ที่ออกจากเครื่อง edc',
  `status` tinyint(1) DEFAULT '1' COMMENT '1 ปกติ 0 ยกเลิกรายการ',
  `right_id` int(11) DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `approve_code` (`approve_code`),
  KEY `pay_date` (`datetime`),
  KEY `pid` (`pid`),
  KEY `edc_id` (`edc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
