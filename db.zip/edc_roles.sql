# ************************************************************
# Sequel Pro SQL dump
# Version (null)
#
# https://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 192.168.0.218 (MySQL 5.6.17-ndb-7.3.5-cluster-gpl-log)
# Database: hospdata
# Generation Time: 2019-10-03 04:52:20 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
SET NAMES utf8mb4;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table edc_roles
# ------------------------------------------------------------

DROP TABLE IF EXISTS `edc_roles`;

CREATE TABLE `edc_roles` (
  `code` char(2) NOT NULL DEFAULT '',
  `name` varchar(255) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

LOCK TABLES `edc_roles` WRITE;
/*!40000 ALTER TABLE `edc_roles` DISABLE KEYS */;

INSERT INTO `edc_roles` (`code`, `name`, `order`, `status`)
VALUES
	('11','ผู้ป่วยนอกทั่วไป สิทธิตนเองและครอบครัว',1,1),
	('12','ผู้ป่วยนอกทั่วไป สิทธิบุตร 0-7 ปี',2,1),
	('13','ผู้ป่วยนอกทั่วไป สิทธิคู่สมรสต่างชาติ',3,1),
	('14','ผู้ป่วยนอกทั่วไป ไม่สามารถใช้บัตรได้',4,1),
	('21','หน่วยไตเทียม สิทธิตนเองและครอบครัว',5,0),
	('22','หน่วยไตเทียม สิทธิบุตร 0-7 ปี',6,0),
	('23','หน่วยไตเทียม สิทธิคู่สมรสต่างชาติ',7,0),
	('24','หน่วยไตเทียม ไม่สามารถใช้บัตรได้',8,0),
	('26','รายการยกเลิก',15,0),
	('31','หน่วยรังสีผู้เป็นมะเร็ง สิทธิตนเองและครอบครัว',9,0),
	('32','หน่วยรังสีผู้เป็นมะเร็ง สิทธิบุตร 0-7 ปี',10,0),
	('33','หน่วยรังสีผู้เป็นมะเร็ง สิทธิคู่สมรสต่างชาติ',11,0),
	('34','หน่วยรังสีผู้เป็นมะเร็ง ไม่สามารถใช้บัตรได้',12,0),
	('50','รายการโอนยอด',13,0),
	('92','รายการพิมพ์สลิปซ้ำ',14,0);

/*!40000 ALTER TABLE `edc_roles` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
